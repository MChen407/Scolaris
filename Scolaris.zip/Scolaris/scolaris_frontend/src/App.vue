<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script setup>
// App principal - routage géré par Vue Router
</script>